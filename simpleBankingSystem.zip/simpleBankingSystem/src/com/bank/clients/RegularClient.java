package com.bank.clients;

public class RegularClient extends Client {
	public RegularClient(String name) {
		super(name, 500);
	}
}
