package com.bank.interfaces;
public class Transactable{
public static void main(String[] arg){

}
}