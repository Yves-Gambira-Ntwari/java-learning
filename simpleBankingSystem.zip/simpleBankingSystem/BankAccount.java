package com.bank;
public class Transactable{
public static void main(String[] arg){

}
}