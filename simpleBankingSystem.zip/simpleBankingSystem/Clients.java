package com.bank.clients;
public class Transactable{
public static void main(String[] arg){
  
}
}